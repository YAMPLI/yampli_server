module.exports.authValidation = require('./auth.validation');
